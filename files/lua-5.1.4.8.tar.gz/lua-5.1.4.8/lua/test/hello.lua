-- the first program in every language

io.write("Hello world, from ",_VERSION,"!\n")
